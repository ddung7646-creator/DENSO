"""KPI tables for the deck, from logs/cycles.csv (+ demo comparison).

    python -m analysis.kpi                                  # KPI per variant → logs/kpi.md, logs/kpi.csv
    python -m analysis.kpi --compare demos/B_expert_top_reps.csv demos/B_novice_top_reps.csv

Every number printed here is MEASURED; label it so in the deck, with n (cycles/reps).
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def kpi(cycles: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (v, d), g in cycles.groupby(["variant_id", "direction"]):
        ok = g["final_status"] == "PASS"
        rows.append({
            "variant": v, "direction": d, "n_cycles": len(g),
            "success_rate_%": round(100 * ok.mean(), 1),
            "cycle_time_median_s": round(g.loc[ok, "cycle_time_s"].median(), 2) if ok.any() else np.nan,
            "cycle_time_p90_s": round(g.loc[ok, "cycle_time_s"].quantile(0.9), 2) if ok.any() else np.nan,
            "retry_rate_%": round(100 * (g["retry_count"] > 0).mean(), 1),
            "fails": "; ".join(f"{k}×{n}" for k, n in g.loc[~ok, "fail_state"].value_counts().items()) or "-",
            "insert_peak_dtorque_pass_max_nm": round(g.loc[ok, "insert_peak_dtorque_nm"].max(), 3) if ok.any() else np.nan,
            # suggested jam threshold: 1.5 × the worst peak seen on successful insertions
            "jam_threshold_suggest_nm": round(1.5 * g.loc[ok, "insert_peak_dtorque_nm"].max(), 3) if ok.any() else np.nan,
        })
    return pd.DataFrame(rows)


def changeovers(events: pd.DataFrame, cycles: pd.DataFrame) -> pd.DataFrame:
    """Time from the last cycle of one variant to the first cycle of the next (includes recipe load)."""
    cycles = cycles.assign(ts=pd.to_datetime(cycles["timestamp"])).sort_values("ts")
    out = []
    prev = None
    for _, c in cycles.iterrows():
        if prev is not None and c["variant_id"] != prev["variant_id"]:
            gap = (c["ts"] - prev["ts"]).total_seconds() - prev["cycle_time_s"]
            out.append({"from": prev["variant_id"], "to": c["variant_id"], "changeover_s": round(gap, 1)})
        prev = c
    return pd.DataFrame(out)


def compare(files):
    tabs = {}
    for f in files:
        df = pd.read_csv(f)
        num = df.select_dtypes("number").drop(columns=["rep"], errors="ignore")
        tabs[Path(f).stem.replace("_reps", "")] = num.median().round(3)
    return pd.DataFrame(tabs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--logs", default=str(Path(__file__).resolve().parents[1] / "logs"))
    ap.add_argument("--compare", nargs="+")
    a = ap.parse_args()
    if a.compare:
        t = compare(a.compare)
        print(t.to_markdown())
        return
    logs = Path(a.logs)
    cyc = pd.read_csv(logs / "cycles.csv")
    k = kpi(cyc)
    k.to_csv(logs / "kpi.csv", index=False)
    md = ["# KPI (measured)", "", k.to_markdown(index=False)]
    if (logs / "events.csv").exists():
        co = changeovers(pd.read_csv(logs / "events.csv"), cyc)
        if len(co):
            md += ["", "## Changeover", "", co.to_markdown(index=False)]
    (logs / "kpi.md").write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md))


if __name__ == "__main__":
    main()
