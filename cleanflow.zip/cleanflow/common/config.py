"""Load config.yaml and recipes, derive slot coordinates, validate recipes.

Everything geometric lives in the *board frame* (see config.yaml header).
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


class ConfigError(ValueError):
    pass


def load_config(path: str | os.PathLike | None = None) -> dict:
    path = Path(path) if path else ROOT / "config.yaml"
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cfg["_root"] = str(path.parent)
    return cfg


@dataclass(frozen=True)
class Slot:
    id: str          # e.g. PA1 (pick, variant A, col 1) / QA1 (place)
    variant: str
    kind: str        # "pick" | "place"
    x: float
    y: float
    hole_d: float
    hole_depth: float


def slots(cfg: dict, variant: str, kind: str) -> list[Slot]:
    j = cfg["jigs"]
    if variant not in j["rows"]:
        raise ConfigError(f"variant {variant!r} không có hàng lỗ trong jigs.rows")
    row = j["rows"][variant]
    x0 = j[kind]["x0_mm"]
    d = row["pick_d_mm" if kind == "pick" else "place_d_mm"]
    prefix = "P" if kind == "pick" else "Q"
    return [
        Slot(f"{prefix}{variant}{k + 1}", variant, kind, x0 + k * j["pitch_mm"], row["y_mm"], d, row["depth_mm"])
        for k in range(j["cols"])
    ]


def board_bounds(cfg: dict) -> tuple[float, float, float, float]:
    xs = [c[0] for c in cfg["board"]["marker_centers_mm"].values()]
    ys = [c[1] for c in cfg["board"]["marker_centers_mm"].values()]
    return min(xs), max(xs), min(ys), max(ys)


# ---------------------------------------------------------------- recipes
RECIPE_SCHEMA = {
    "variant": str,
    "recipe_version": (str, int, float),
    "part": {"length_mm": float, "head_height_mm": float, "head_d_mm": float, "shank_d_mm": float},
    "grip": {"depth_from_head_top_mm": float, "open_width_mm": float, "close_width_mm": float,
             "force_pct": float, "dwell_s": float},
    "motion": {"clearance_mm": float, "slow_zone_mm": float, "approach_speed_pct": float,
               "transfer_speed_pct": float, "insert_speed_pct": float, "blend_mm": float},
    "insert": {"jam_dtorque_nm": float},
    "retry": {"max_grasp_retries": int},
}


def _check(node, schema, path, errors):
    for key, typ in schema.items():
        p = f"{path}.{key}" if path else key
        if key not in node:
            errors.append(f"thiếu trường {p}")
            continue
        val = node[key]
        if isinstance(typ, dict):
            if not isinstance(val, dict):
                errors.append(f"{p} phải là mapping")
            else:
                _check(val, typ, p, errors)
        elif typ is float:
            if not isinstance(val, (int, float)) or isinstance(val, bool):
                errors.append(f"{p} phải là số, đang là {val!r}")
        elif not isinstance(val, typ):
            errors.append(f"{p} sai kiểu: {val!r}")


def validate_recipe(r: dict, cfg: dict) -> list[str]:
    errors: list[str] = []
    _check(r, RECIPE_SCHEMA, "", errors)
    if errors:
        return errors
    s, g, m, p = cfg["safety"], r["grip"], r["motion"], r["part"]
    if r["variant"] not in cfg["jigs"]["rows"]:
        errors.append(f"variant {r['variant']} không có trong jigs.rows")
    for k in ("approach_speed_pct", "transfer_speed_pct"):
        if not 0 < m[k] <= s["max_vel_pct"]:
            errors.append(f"motion.{k}={m[k]} ngoài (0, {s['max_vel_pct']}]")
    if not 0 < m["insert_speed_pct"] <= s["max_insert_vel_pct"]:
        errors.append(f"motion.insert_speed_pct={m['insert_speed_pct']} ngoài (0, {s['max_insert_vel_pct']}]")
    if not 0 < g["force_pct"] <= s["max_grip_force_pct"]:
        errors.append(f"grip.force_pct={g['force_pct']} ngoài (0, {s['max_grip_force_pct']}]")
    if g["open_width_mm"] > cfg["gripper"]["stroke_mm"]:
        errors.append("grip.open_width_mm lớn hơn hành trình gripper")
    if g["close_width_mm"] >= g["open_width_mm"]:
        errors.append("grip.close_width_mm phải nhỏ hơn open_width_mm")
    if not 0 < g["depth_from_head_top_mm"] < p["length_mm"]:
        errors.append("grip.depth_from_head_top_mm phải nằm trong chiều dài ốc")
    if m["slow_zone_mm"] > m["clearance_mm"]:
        errors.append("motion.slow_zone_mm phải ≤ clearance_mm")
    if not errors and r["variant"] in cfg["jigs"]["rows"]:
        from common.geometry import plan_z  # local import: geometry depends on this module
        try:
            plan_z(r, cfg)
        except ConfigError as e:
            errors.append(str(e))
    return errors


def load_recipe(variant_or_path: str, cfg: dict) -> dict:
    p = Path(variant_or_path)
    if not p.suffix:
        p = Path(cfg["_root"]) / "recipes" / f"{variant_or_path}.yaml"
    with open(p, encoding="utf-8") as f:
        r = yaml.safe_load(f)
    errs = validate_recipe(r, cfg)
    if errs:
        raise ConfigError(f"Recipe {p.name} không hợp lệ:\n  - " + "\n  - ".join(errs))
    r["_path"] = str(p)
    return r


def recipes_available(cfg: dict) -> dict[str, dict]:
    out = {}
    for p in sorted((Path(cfg["_root"]) / "recipes").glob("*.yaml")):
        try:
            r = load_recipe(str(p), cfg)
            out[r["variant"]] = r
        except ConfigError:
            continue
    return out
