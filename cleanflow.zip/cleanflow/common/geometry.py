"""Z-height planning for screw pick/insert, all in the board frame (Z=0 = plate surface).

A screw standing in a hole of depth D either rests on the hole bottom (shank longer than D)
or hangs by its head on the surface (shank ≤ D). The grip point is described by the recipe as
`depth_from_head_top_mm` – what the side camera measures on the human demo.
"""
from __future__ import annotations

from dataclasses import dataclass

from common.config import ConfigError


@dataclass(frozen=True)
class ZPlan:
    head_top_pick: float      # z of screw head top while standing in the pick jig
    grip_pick: float          # TCP z when gripping in the pick jig
    contact_place: float      # TCP z when the screw tip touches the place-hole mouth
    seated_place: float       # TCP z when the screw is fully seated in the place jig
    travel: float             # TCP z for horizontal travel (clears every standing screw)
    width_at_grip: float      # part width between the fingers


def head_top_z(length: float, head_h: float, depth: float) -> float:
    shank = length - head_h
    return head_h + max(0.0, shank - depth)


def plan_z(recipe: dict, cfg: dict) -> ZPlan:
    p, g, m = recipe["part"], recipe["grip"], recipe["motion"]
    row = cfg["jigs"]["rows"][recipe["variant"]]
    depth = row["depth_mm"]
    L, hh, dg = p["length_mm"], p["head_height_mm"], g["depth_from_head_top_mm"]

    top = head_top_z(L, hh, depth)
    grip = top - dg
    seated = top - dg                       # same jig depth for pick and place rows
    contact = L - dg                        # screw tip at z=0
    width = p["head_d_mm"] if dg < hh else p["shank_d_mm"]

    half = cfg["gripper"]["finger_half_height_mm"]
    min_clear = cfg["gripper"]["min_finger_clearance_mm"]
    if grip - half < min_clear:
        raise ConfigError(
            f"đầu ngón sẽ chạm mặt đế khi kẹp (mép dưới ngón ở z={grip - half:.1f} mm). "
            f"Kẹp cao hơn (giảm grip.depth_from_head_top_mm) hoặc khoan lỗ {recipe['variant']} nông hơn.")
    if g["close_width_mm"] >= width:
        raise ConfigError(f"grip.close_width_mm={g['close_width_mm']} phải nhỏ hơn bề rộng tại điểm kẹp ({width} mm) để có lực kẹp")
    if g["open_width_mm"] <= width + 2:
        raise ConfigError(f"grip.open_width_mm={g['open_width_mm']} quá sát bề rộng part ({width} mm), cần dư ≥ 2 mm")

    # travel height: carried screw tip must clear the tallest standing screw by 5 mm,
    # and the lift must pull the screw completely out of its hole.
    tallest = max(top, cfg["safety"]["max_standing_part_mm"])  # cao nhất trong mọi ốc đang đứng trên tấm đế
    tip_offset = L - dg                     # tip is this far below TCP
    travel = max(grip + m["clearance_mm"], tallest + 5.0 + tip_offset, grip + depth + 5.0)
    if travel > cfg["safety"]["z_max_mm"]:
        raise ConfigError(f"độ cao di chuyển {travel:.1f} vượt safety.z_max_mm")
    return ZPlan(top, grip, contact, seated, travel, width)
