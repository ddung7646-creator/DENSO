"""Honest re-evaluation of the drawing-robot torque classifier (team capability evidence).

The original train_from_real_data.py split rows at random. Rows from the same log file are
consecutive samples and nearly identical, so a random split leaks and inflates accuracy.
This script holds out whole files (GroupKFold) – the number to quote on the Team slide.

    python legacy/eval_torque_classifier.py --data path/to/data/data_train

Result on the team's 759 rows / 17 files (checked 2026-09-29):
    random split ≈ 79 %   |   held-out files ≈ 76 %   |   majority-class baseline ≈ 43 %
Do NOT reuse the model for screws: different tool, pose and task.
"""
import argparse
import glob
import os

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GroupKFold, StratifiedKFold, cross_val_score

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True)
a = ap.parse_args()
frames = []
for f in glob.glob(os.path.join(a.data, "*.xlsx")):
    d = pd.read_excel(f)
    d["file"] = os.path.basename(f)
    frames.append(d)
D = pd.concat(frames, ignore_index=True)
cols = [f"J{i} (Nm)" for i in range(1, 7)]
D = D.dropna(subset=cols + ["Status"])
X, y, g = D[cols].values, D["Status"].str.strip().str.upper().values, D["file"].values
m = RandomForestClassifier(n_estimators=100, max_depth=15, min_samples_split=5, random_state=42)
print(f"rows={len(D)} files={D['file'].nunique()} classes={pd.Series(y).value_counts().to_dict()}")
print("random split  :", round(cross_val_score(m, X, y, cv=StratifiedKFold(5, shuffle=True, random_state=0)).mean(), 3))
print("held-out files:", round(cross_val_score(m, X, y, cv=GroupKFold(5), groups=g).mean(), 3))
print("baseline      :", round(pd.Series(y).value_counts(normalize=True).max(), 3))
