Tải model HandLandmarker (MediaPipe Tasks) và lưu đúng tên hand_landmarker.task trong thư mục này:
https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
