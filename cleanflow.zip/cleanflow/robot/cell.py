"""Pick–insert state machine driven by a Skill Recipe.

HOME → PRE_PICK → DESCEND → GRASP → VERIFY_GRASP → LIFT → TRANSFER → PRE_PLACE → INSERT
     → RELEASE → VERIFY_PLACE → LOG

Safety behaviour built in:
  * every target goes through SafetyGuard (workspace box, z limits, speed/force caps),
  * the last millimetres of every descent run non-blocking under a torque watch
    (unexpected contact → StopMotion), insertion under the recipe's jam threshold,
  * on a jam the screw is NOT dropped: the robot lifts, returns it to its pick hole, releases,
  * a missed grasp is retried `retry.max_grasp_retries` times, then the slot is skipped,
  * optional step mode: every motion waits for Enter.
"""
from __future__ import annotations

import csv
import os
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path

from common.config import Slot
from common.geometry import plan_z
from robot.torque_log import TorqueWatch

LOG_FIELDS = [
    "cycle_id", "timestamp", "variant_id", "recipe_version", "direction", "pick_slot", "place_slot",
    "pick_verified", "placement_verified", "cycle_time_s", "retry_count", "final_status", "fail_state",
    "grip_pos_pct", "grip_current_pct", "insert_peak_dtorque_nm",
]


@dataclass
class CycleResult:
    cycle_id: int
    variant_id: str
    recipe_version: str
    direction: str
    pick_slot: str
    place_slot: str
    timestamp: str = ""
    pick_verified: bool | None = None
    placement_verified: bool | None = None
    cycle_time_s: float = 0.0
    retry_count: int = 0
    final_status: str = "PENDING"      # PASS | FAIL
    fail_state: str = ""               # MISS_GRASP | JAM | CONTACT | VERIFY_PLACE | ERROR:<msg>
    grip_pos_pct: float | None = None
    grip_current_pct: float | None = None
    insert_peak_dtorque_nm: float | None = None
    torque_trace: list = field(default_factory=list, repr=False)


class CycleLogger:
    def __init__(self, log_dir: str):
        self.dir = Path(log_dir)
        (self.dir / "torque").mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "cycles.csv"
        self.events = self.dir / "events.csv"
        if not self.path.exists():
            with open(self.path, "w", newline="") as f:
                csv.DictWriter(f, LOG_FIELDS).writeheader()
        if not self.events.exists():
            with open(self.events, "w", newline="") as f:
                csv.writer(f).writerow(["timestamp", "event", "detail"])

    def next_cycle_id(self) -> int:
        with open(self.path) as f:
            return sum(1 for _ in f)  # header counts as 1 → ids start at 1

    def event(self, name: str, detail: str = ""):
        with open(self.events, "a", newline="") as f:
            csv.writer(f).writerow([datetime.now().isoformat(timespec="milliseconds"), name, detail])

    def write(self, r: CycleResult):
        row = {k: v for k, v in asdict(r).items() if k in LOG_FIELDS}
        with open(self.path, "a", newline="") as f:
            csv.DictWriter(f, LOG_FIELDS).writerow(row)
        if r.torque_trace:
            with open(self.dir / "torque" / f"cycle_{r.cycle_id:04d}.csv", "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(["t_s", "delta_nm"])
                w.writerows(r.torque_trace)


class Cell:
    def __init__(self, robot, cfg: dict, logger: CycleLogger, verifier=None, step: bool = False):
        self.robot, self.cfg, self.log, self.verifier, self.step = robot, cfg, logger, verifier, step
        self.recipe = None
        self.z = None

    # ------------------------------------------------------------------ setup
    def load(self, recipe: dict):
        old = self.recipe["variant"] if self.recipe else None
        self.recipe = recipe
        self.z = plan_z(recipe, self.cfg)
        self.log.event("recipe_loaded", f"{old}->{recipe['variant']} v{recipe['recipe_version']} {os.path.basename(recipe['_path'])}")

    def home(self):
        self._move(self.cfg["robot"]["home_xyz"], self.recipe["motion"]["transfer_speed_pct"] if self.recipe else 20)

    # ------------------------------------------------------------------ primitives
    def _confirm(self, what):
        if self.step:
            input(f"[STEP] {what} – Enter để chạy, Ctrl+C để dừng ")

    def _move(self, xyz, vel, cap=None):
        self._confirm(f"MoveL {tuple(round(v, 1) for v in xyz)} vel={vel}")
        self.robot.move_l(xyz, vel, blocking=True, cap=cap)

    def _guarded(self, xyz, vel, threshold, cap=None) -> tuple[bool, TorqueWatch]:
        """Non-blocking move under a torque watch. Returns (completed, watch)."""
        tc = self.cfg["torque"]
        w = TorqueWatch(self.robot, tc["joints"], threshold)
        w.take_baseline(tc["baseline_samples"] if self.cfg["robot"]["mode"] != "mock" else 1, tc["sample_hz"])
        self._confirm(f"MoveL (có giám sát torque, ngưỡng {threshold} Nm) → {tuple(round(v, 1) for v in xyz)}")
        self.robot.move_l(xyz, vel, blocking=False, cap=cap)
        done = self.robot.wait_motion(poll=w.poll)
        return done, w

    def _grasp_ok(self, res: CycleResult) -> bool | None:
        pos, cur = self.robot.gripper_state()
        res.grip_pos_pct, res.grip_current_pct = pos, cur
        g = self.cfg["gripper"]
        if pos is None or g.get("empty_close_pct") is None:
            return None                       # no feedback / not calibrated → unknown
        return abs(pos - g["empty_close_pct"]) >= g["empty_tol_pct"]

    # ------------------------------------------------------------------ one cycle
    def run_cycle(self, pick: Slot, place: Slot, direction="forward") -> CycleResult:
        r, z = self.recipe, self.z
        g, m = r["grip"], r["motion"]
        res = CycleResult(self.log.next_cycle_id(), r["variant"], str(r["recipe_version"]), direction, pick.id, place.id,
                          timestamp=datetime.now().isoformat(timespec="seconds"))
        t0 = time.time()
        fast, slow, ins = m["transfer_speed_pct"], m["approach_speed_pct"], m["insert_speed_pct"]
        ins_cap = self.cfg["safety"]["max_insert_vel_pct"]
        contact_nm = self.cfg["torque"]["unexpected_contact_nm"]
        state = "PRE_PICK"
        try:
            for attempt in range(r["retry"]["max_grasp_retries"] + 1):
                res.retry_count = attempt
                # PRE_PICK: open while above the slot
                state = "PRE_PICK"
                self._move((pick.x, pick.y, z.travel), fast)
                self.robot.gripper(g["open_width_mm"], g["force_pct"], blocking=True)
                # DESCEND: fast to slow-zone, then guarded slow approach
                state = "DESCEND"
                self._move((pick.x, pick.y, z.grip_pick + m["slow_zone_mm"]), fast)
                done, _ = self._guarded((pick.x, pick.y, z.grip_pick), slow, contact_nm)
                if not done:
                    res.fail_state = "CONTACT"
                    self._move((pick.x, pick.y, z.travel), slow)
                    break
                # GRASP
                state = "GRASP"
                self.robot.gripper(g["close_width_mm"], g["force_pct"], blocking=True)
                time.sleep(g["dwell_s"] if self.cfg["robot"]["mode"] != "mock" else 0)
                state = "VERIFY_GRASP"
                ok = self._grasp_ok(res)
                res.pick_verified = ok
                if ok is False:
                    self.robot.gripper(g["open_width_mm"], g["force_pct"], blocking=True)
                    self._move((pick.x, pick.y, z.travel), slow)
                    res.fail_state = "MISS_GRASP"
                    continue
                res.fail_state = ""
                break
            if res.fail_state:
                raise _CycleFail(res.fail_state)

            # LIFT: slow out of the hole, then fast
            state = "LIFT"
            self._move((pick.x, pick.y, z.grip_pick + m["slow_zone_mm"]), slow)
            self._move((pick.x, pick.y, z.travel), fast)
            # TRANSFER
            state = "TRANSFER"
            self._move((place.x, place.y, z.travel), fast)
            # PRE_PLACE: fast to slow-zone above hole mouth, slow to just above contact
            state = "PRE_PLACE"
            self._move((place.x, place.y, z.contact_place + m["slow_zone_mm"]), fast)
            self._move((place.x, place.y, z.contact_place + 1.0), slow)
            # INSERT under jam watch
            state = "INSERT"
            done, w = self._guarded((place.x, place.y, z.seated_place), ins, r["insert"]["jam_dtorque_nm"], cap=ins_cap)
            res.insert_peak_dtorque_nm = round(w.peak, 4)
            res.torque_trace = [(round(t, 4), round(d, 4)) for t, d in w.samples]
            if not done:
                self._recover_jam(pick, place)
                raise _CycleFail("JAM")
            # RELEASE
            state = "RELEASE"
            self.robot.gripper(g["open_width_mm"], g["force_pct"], blocking=True)
            self._move((place.x, place.y, z.seated_place + m["slow_zone_mm"]), slow)
            self._move((place.x, place.y, z.travel), fast)
            # VERIFY_PLACE
            state = "VERIFY_PLACE"
            if self.verifier:
                res.placement_verified = bool(self.verifier(place))
                if not res.placement_verified:
                    raise _CycleFail("VERIFY_PLACE")
            res.final_status = "PASS"
        except _CycleFail as e:
            res.final_status, res.fail_state = "FAIL", str(e)
        except Exception as e:  # safety violation, SDK error… stop and surface it
            self.robot.stop()
            res.final_status, res.fail_state = "FAIL", f"ERROR@{state}:{e}"
            res.cycle_time_s = round(time.time() - t0, 3)
            self.log.write(res)
            raise
        res.cycle_time_s = round(time.time() - t0, 3)
        self.log.write(res)
        return res

    def _recover_jam(self, pick: Slot, place: Slot):
        """Keep hold of the screw, back it out slowly, put it back in its (loose) pick hole."""
        g, m, z = self.recipe["grip"], self.recipe["motion"], self.z
        self._move((place.x, place.y, z.contact_place + m["slow_zone_mm"]), m["insert_speed_pct"],
                   cap=self.cfg["safety"]["max_insert_vel_pct"])
        self._move((place.x, place.y, z.travel), m["approach_speed_pct"])
        self._move((pick.x, pick.y, z.travel), m["transfer_speed_pct"])
        self._move((pick.x, pick.y, z.grip_pick + 1.0), m["approach_speed_pct"])
        self.robot.gripper(g["open_width_mm"], g["force_pct"], blocking=True)
        self._move((pick.x, pick.y, z.travel), m["approach_speed_pct"])


class _CycleFail(Exception):
    pass
