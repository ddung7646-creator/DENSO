"""Thin, safety-checked wrapper over the Fairino Python SDK, plus a MockRobot for dry runs.

All poses passed in are (x, y, z) in the *board frame*; they are sent to the controller in the
user frame `robot.user`, which must be taught so that it coincides with the board frame.

SDK facts this wrapper relies on (checked against fairino/Robot.py in the team's SDK copy):
  * Every call returns an error code (0 = OK). Getters return (err, value...).
  * MoveL blendR = -1 → blocking; blendR ≥ 0 → non-blocking (returns immediately).
  * MoveGripper block: 0 = BLOCKING, 1 = NON-blocking (the opposite of what many expect).
  * GetJointTorques / GetActualTCPPose / GetRobotMotionDone / GetGripperCurPosition read the
    real-time state packet (no XML-RPC round-trip) → safe to poll fast from the main thread.
  * xmlrpc ServerProxy is not thread-safe → only ONE thread sends commands (the main thread).
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

from common.config import board_bounds


class RobotError(RuntimeError):
    pass


class SafetyViolation(RuntimeError):
    pass


# --------------------------------------------------------------------------- safety
class SafetyGuard:
    """Checks every target before it reaches the controller."""

    def __init__(self, cfg: dict):
        s = cfg["safety"]
        self.cfg = cfg
        x0, x1, y0, y1 = board_bounds(cfg)
        mg = s["workspace_margin_mm"]
        self.box = (x0 - mg, x1 + mg, y0 - mg, y1 + mg, s["z_min_mm"], s["z_max_mm"])
        self.max_vel = s["max_vel_pct"]
        self.max_force = s["max_grip_force_pct"]

    def check_xyz(self, xyz):
        x, y, z = xyz
        x0, x1, y0, y1, z0, z1 = self.box
        if not (x0 <= x <= x1 and y0 <= y <= y1):
            raise SafetyViolation(f"điểm ({x:.1f},{y:.1f}) nằm ngoài vùng làm việc của tấm đế")
        if not (z0 <= z <= z1):
            raise SafetyViolation(f"z={z:.1f} ngoài giới hạn [{z0}, {z1}]")
        if any(math.isnan(v) for v in xyz):
            raise SafetyViolation("tọa độ NaN")

    def clamp_vel(self, vel: float, cap: float | None = None) -> float:
        cap = min(self.max_vel, cap) if cap else self.max_vel
        return max(1.0, min(float(vel), cap))

    def clamp_force(self, f: float) -> float:
        return max(1.0, min(float(f), self.max_force))


# --------------------------------------------------------------------------- base
class BaseRobot:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.guard = SafetyGuard(cfg)
        r = cfg["robot"]
        self.tool, self.user = r["tool"], r["user"]
        self.rot = list(map(float, r["tool_orientation_deg"]))

    # helpers shared by implementations
    def pose(self, xyz):
        return [float(xyz[0]), float(xyz[1]), float(xyz[2])] + self.rot

    def width_to_pct(self, width_mm: float) -> float:
        g = self.cfg["gripper"]
        frac = max(0.0, min(1.0, width_mm / g["stroke_mm"]))
        return g["pct_closed"] + frac * (g["pct_open"] - g["pct_closed"])

    # interface
    def connect(self): ...
    def close(self): ...
    def move_l(self, xyz, vel_pct: float, blocking: bool = True, cap: float | None = None): ...
    def wait_motion(self, timeout: float | None = None, poll=None) -> bool: ...
    def stop(self): ...
    def gripper(self, width_mm: float, force_pct: float, blocking: bool = True): ...
    def gripper_state(self) -> tuple[float | None, float | None]: ...
    def joint_torques(self) -> list[float]: ...
    def tcp_xyz(self) -> list[float]: ...


# --------------------------------------------------------------------------- real / sim
class FairinoRobot(BaseRobot):
    def __init__(self, cfg: dict, ip: str):
        super().__init__(cfg)
        self.ip = ip
        self.rpc = None

    def _ok(self, ret, what):
        err = ret[0] if isinstance(ret, (tuple, list)) else ret
        if err != 0:
            raise RobotError(f"{what} lỗi mã {err}")
        return ret

    def connect(self):
        from fairino import Robot  # imported lazily so mock mode needs no SDK
        self.rpc = Robot.RPC(self.ip)
        s = self.cfg["safety"]
        err, codes = self.rpc.GetRobotErrorCode()
        if codes and any(codes):
            raise RobotError(f"controller đang báo lỗi {codes}. Xử lý trên WebApp rồi chạy lại.")
        self._ok(self.rpc.SetSpeed(int(s["global_speed_pct"])), "SetSpeed")
        col = s.get("collision") or {}
        if col.get("level"):
            self._ok(self.rpc.SetAnticollision(0, col["level"], 0), "SetAnticollision")
        if col.get("strategy") is not None:
            self._ok(self.rpc.SetCollisionStrategy(int(col["strategy"])), "SetCollisionStrategy")
        g = self.cfg["gripper"]
        self._ok(self.rpc.ActGripper(g["index"], 1), "ActGripper")
        time.sleep(1.0)

    def close(self):
        if self.rpc:
            try:
                self.rpc.CloseRPC()
            finally:
                self.rpc = None

    def move_l(self, xyz, vel_pct, blocking=True, cap=None):
        self.guard.check_xyz(xyz)
        vel = self.guard.clamp_vel(vel_pct, cap)
        blend = -1.0 if blocking else 0.0
        self._ok(self.rpc.MoveL(self.pose(xyz), self.tool, self.user, vel=vel, blendR=blend), f"MoveL{tuple(round(v,1) for v in xyz)}")
        if not blocking:
            time.sleep(0.05)  # let motion_done drop to 0 before callers poll it

    def wait_motion(self, timeout=None, poll=None):
        """Poll until motion done. `poll()` runs every cycle; returning True aborts (StopMotion)."""
        timeout = timeout or self.cfg["safety"]["motion_timeout_s"]
        t0 = time.time()
        while True:
            if poll and poll():
                self.stop()
                return False
            _, done = self.rpc.GetRobotMotionDone()
            if done == 1:
                return True
            if time.time() - t0 > timeout:
                self.stop()
                raise RobotError("chuyển động quá thời gian cho phép – đã dừng")
            time.sleep(1.0 / self.cfg["torque"]["sample_hz"])

    def stop(self):
        if self.rpc:
            self.rpc.StopMotion()

    def gripper(self, width_mm, force_pct, blocking=True):
        g = self.cfg["gripper"]
        pos = int(round(self.width_to_pct(width_mm)))
        force = int(self.guard.clamp_force(force_pct))
        block = 0 if blocking else 1          # SDK: 0 = blocking, 1 = non-blocking
        self._ok(self.rpc.MoveGripper(g["index"], pos, g["vel_pct"], force, g["max_time_ms"], block, 0, 0, 0, 0), "MoveGripper")

    def gripper_state(self):
        if not self.cfg["gripper"]["has_feedback"]:
            return None, None
        _, fault, pos = self.rpc.GetGripperCurPosition()
        _, fault2, cur = self.rpc.GetGripperCurCurrent()
        if fault or fault2:
            raise RobotError("gripper báo lỗi")
        return float(pos), float(cur)

    def joint_torques(self):
        return list(self.rpc.GetJointTorques(1)[1])

    def tcp_xyz(self):
        return list(self.rpc.GetActualTCPPose(1)[1][:3])


# --------------------------------------------------------------------------- mock
@dataclass
class MockWorld:
    """Scripted faults for tests: e.g. {'miss_grasp': {1}, 'jam_insert': {2}} (cycle numbers)."""
    faults: dict = field(default_factory=dict)
    cycle: int = 0
    holding: bool = False


class MockRobot(BaseRobot):
    """Simulates motion instantly, records a trace. Same safety checks as the real robot."""

    def __init__(self, cfg: dict, world: MockWorld | None = None, verbose=False):
        super().__init__(cfg)
        self.world = world or MockWorld()
        self.trace: list[tuple] = []
        self.xyz = list(cfg["robot"]["home_xyz"])
        self.verbose = verbose
        self._grip_pct = 100.0
        self._inserting = False

    def connect(self):
        self.trace.append(("connect",))

    def close(self):
        self.trace.append(("close",))

    def move_l(self, xyz, vel_pct, blocking=True, cap=None):
        self.guard.check_xyz(xyz)
        vel = self.guard.clamp_vel(vel_pct, cap)
        self.trace.append(("move", tuple(round(v, 2) for v in xyz), vel, blocking))
        if self.verbose:
            print(f"  MoveL → ({xyz[0]:.1f}, {xyz[1]:.1f}, {xyz[2]:.1f})  vel={vel:.0f}%  {'blk' if blocking else 'nb'}")
        self._target = list(xyz)
        if blocking:
            self.xyz = list(xyz)

    def wait_motion(self, timeout=None, poll=None):
        self._inserting = True
        if poll:
            for _ in range(5):
                if poll():
                    self.trace.append(("stop",))
                    self._inserting = False
                    return False
        self.xyz = list(self._target)
        self._inserting = False
        return True

    def stop(self):
        self.trace.append(("stop",))

    def gripper(self, width_mm, force_pct, blocking=True):
        pct = self.width_to_pct(width_mm)
        self.trace.append(("gripper", round(width_mm, 2), self.guard.clamp_force(force_pct)))
        if pct < 50:  # closing
            missed = self.world.cycle in self.world.faults.get("miss_grasp", set())
            self.world.holding = not missed
            empty = self.cfg["gripper"].get("empty_close_pct")
            self._grip_pct = (empty if empty is not None else 0.0) if missed else pct + 12.0
        else:
            self.world.holding = False
            self._grip_pct = pct

    def gripper_state(self):
        return self._grip_pct, (35.0 if self.world.holding else 5.0)

    def joint_torques(self):
        at_place = self._inserting and self._target[0] >= self.cfg["jigs"]["place"]["x0_mm"] - 15
        jam = at_place and self.world.cycle in self.world.faults.get("jam_insert", set())
        return [0.0, 0.2 + (3.0 if jam else 0.0), 0.1, 0.0, 0.0, 0.0]

    def tcp_xyz(self):
        return list(self.xyz)


def make_robot(cfg: dict, world: MockWorld | None = None, verbose=False) -> BaseRobot:
    mode = cfg["robot"]["mode"]
    if mode == "mock":
        return MockRobot(cfg, world, verbose)
    if mode == "sim":
        ip = cfg["robot"]["ip_sim"]
    elif mode == "real":
        ip = cfg["robot"]["ip_real"]
    else:
        raise ValueError(f"robot.mode không hợp lệ: {mode}")
    if not ip or "CHANGE_ME" in str(ip):
        raise ValueError(f"chưa điền IP cho mode={mode} trong config.yaml")
    return FairinoRobot(cfg, ip)
