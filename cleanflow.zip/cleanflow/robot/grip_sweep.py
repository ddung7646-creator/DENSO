"""Gripper calibration and grip-force sweep.

1) Empty-close calibration (do this first, nothing between the fingers):
       python -m robot.grip_sweep --empty
   → prints the position % the gripper reports when it closes on nothing.
     Put it into config.yaml: gripper.empty_close_pct. Enables miss-grasp detection.

2) Force sweep on a real part (screw standing in pick hole 1 of the variant):
       python -m robot.grip_sweep --variant B --forces 10 20 30 40 --reps 5
   For each force: pick, lift to travel height, hold 1 s, check still held, put back, release.
   Writes logs/grip_sweep_<variant>.csv and suggests the lowest force with reps/reps success + one step.
   The success-rate-vs-force table is a ready-made chart for the deck.
"""
from __future__ import annotations

import argparse
import csv
import statistics
import time
from pathlib import Path

from common.config import load_config, load_recipe, slots
from common.geometry import plan_z
from robot.fr5 import make_robot


def empty_close(robot, cfg, reps=5):
    g = cfg["gripper"]
    vals = []
    for _ in range(reps):
        robot.gripper(g["stroke_mm"], 20, blocking=True)
        robot.gripper(0.0, 20, blocking=True)
        time.sleep(0.3)
        pos, _ = robot.gripper_state()
        vals.append(pos)
    robot.gripper(g["stroke_mm"], 20, blocking=True)
    return statistics.median(vals), vals


def sweep(robot, cfg, recipe, forces, reps):
    z = plan_z(recipe, cfg)
    g, m = recipe["grip"], recipe["motion"]
    s = slots(cfg, recipe["variant"], "pick")[0]
    empty = cfg["gripper"]["empty_close_pct"]
    tol = cfg["gripper"]["empty_tol_pct"]
    rows = []
    robot.move_l((s.x, s.y, z.travel), m["transfer_speed_pct"])
    for f in forces:
        for k in range(reps):
            robot.gripper(g["open_width_mm"], f, blocking=True)
            robot.move_l((s.x, s.y, z.grip_pick + m["slow_zone_mm"]), m["transfer_speed_pct"])
            robot.move_l((s.x, s.y, z.grip_pick), m["approach_speed_pct"])
            robot.gripper(g["close_width_mm"], f, blocking=True)
            time.sleep(g["dwell_s"])
            pos0, cur0 = robot.gripper_state()
            robot.move_l((s.x, s.y, z.travel), m["transfer_speed_pct"])
            time.sleep(1.0)
            pos1, cur1 = robot.gripper_state()
            held = None if (pos1 is None or empty is None) else abs(pos1 - empty) >= tol
            robot.move_l((s.x, s.y, z.grip_pick + 1.0), m["approach_speed_pct"])
            robot.gripper(g["open_width_mm"], f, blocking=True)
            robot.move_l((s.x, s.y, z.travel), m["approach_speed_pct"])
            rows.append({"force_pct": f, "rep": k + 1, "pos_closed": pos0, "current_closed": cur0,
                         "pos_after_lift": pos1, "current_after_lift": cur1, "held": held})
            print(f"force {f:3.0f}%  rep {k + 1}: held={held} pos={pos1} cur={cur1}")
    return rows


def suggest(rows, forces, reps):
    ok = {f: sum(1 for r in rows if r["force_pct"] == f and r["held"]) for f in forces}
    good = [f for f in sorted(forces) if ok[f] == reps]
    if not good:
        return None, ok
    i = sorted(forces).index(good[0])
    step_up = sorted(forces)[min(i + 1, len(forces) - 1)]
    return step_up, ok


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--empty", action="store_true")
    ap.add_argument("--variant")
    ap.add_argument("--forces", type=float, nargs="+", default=[10, 20, 30, 40, 50])
    ap.add_argument("--reps", type=int, default=5)
    a = ap.parse_args()
    cfg = load_config()
    robot = make_robot(cfg)
    robot.connect()
    try:
        if a.empty:
            med, vals = empty_close(robot, cfg)
            print(f"empty_close_pct ≈ {med}  (các lần: {vals}) → ghi vào config.yaml gripper.empty_close_pct")
        else:
            rec = load_recipe(a.variant, cfg)
            rows = sweep(robot, cfg, rec, a.forces, a.reps)
            out = Path(cfg["_root"]) / cfg["logging"]["dir"] / f"grip_sweep_{rec['variant']}.csv"
            out.parent.mkdir(parents=True, exist_ok=True)
            with open(out, "w", newline="") as f:
                w = csv.DictWriter(f, rows[0].keys()); w.writeheader(); w.writerows(rows)
            best, ok = suggest(rows, a.forces, a.reps)
            print("Tỉ lệ giữ được:", {f: f"{n}/{a.reps}" for f, n in ok.items()})
            print(f"Gợi ý grip.force_pct = {best}" if best else "Không mức nào đạt 100% – kiểm tra đầu ngón / điểm kẹp")
    except KeyboardInterrupt:
        robot.stop()
    finally:
        robot.close()
