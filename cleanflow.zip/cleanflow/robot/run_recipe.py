"""Run pick–insert cycles from a Skill Recipe.

Examples
    python -m robot.run_recipe --variant A --cycles 4                 # mode from config.yaml
    python -m robot.run_recipe --variant B --cycles 4 --return-trip   # 4 forward + 4 back (no manual reset)
    python -m robot.run_recipe --identify --cycles 4 --verify         # camera picks the recipe, checks placement
    python -m robot.run_recipe --variant A --cycles 1 --step          # confirm every motion (first real run!)
    python -m robot.run_recipe --variant A --mode mock                # dry run, no robot
"""
from __future__ import annotations

import argparse
import sys

from common.config import load_config, load_recipe, slots, ConfigError
from robot.cell import Cell, CycleLogger
from robot.fr5 import make_robot, SafetyViolation, RobotError


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", help="A | B | C | đường dẫn .yaml")
    ap.add_argument("--identify", action="store_true", help="dùng camera nhận diện variant ở ô nhận diện")
    ap.add_argument("--cycles", type=int, default=4, help="số cycle chiều đi (≤ số lỗ trong 1 hàng)")
    ap.add_argument("--return-trip", action="store_true", help="chạy thêm chiều về: lỗ đặt → lỗ lấy")
    ap.add_argument("--verify", action="store_true", help="kiểm tra đặt đúng bằng camera")
    ap.add_argument("--step", action="store_true", help="dừng chờ Enter trước mỗi chuyển động")
    ap.add_argument("--mode", choices=["mock", "sim", "real"], help="ghi đè robot.mode")
    ap.add_argument("--config")
    a = ap.parse_args(argv)

    cfg = load_config(a.config)
    if a.mode:
        cfg["robot"]["mode"] = a.mode
    mode = cfg["robot"]["mode"]

    cam = None
    if a.identify or a.verify:
        from vision.camera import Camera
        cam = Camera(cfg)

    if a.identify:
        from vision.identify import identify_from_camera
        variant, info = identify_from_camera(cam, cfg)
        print(f"Nhận diện: {variant}  ({info})")
        if variant is None:
            sys.exit("Không nhận diện được part – kiểm tra ô nhận diện / ánh sáng.")
    else:
        variant = a.variant
    if not variant:
        ap.error("cần --variant hoặc --identify")

    try:
        recipe = load_recipe(variant, cfg)
    except ConfigError as e:
        sys.exit(str(e))

    if mode == "real" and cfg["safety"]["require_confirm_real"]:
        print(f"ROBOT THẬT – tốc độ toàn cục {cfg['safety']['global_speed_pct']}%. Người đứng cạnh nút E-stop?")
        if input("Gõ RUN để tiếp tục: ").strip() != "RUN":
            sys.exit("Đã huỷ.")

    verifier = None
    if a.verify:
        from vision.verify import PlacementVerifier
        verifier = PlacementVerifier(cam, cfg)
        verifier.capture_reference()   # ảnh tham chiếu khi các lỗ đặt còn trống

    robot = make_robot(cfg, verbose=(mode == "mock"))
    log = CycleLogger(str(__import__("pathlib").Path(cfg["_root"]) / cfg["logging"]["dir"]))
    cell = Cell(robot, cfg, log, verifier, step=a.step)
    picks, places = slots(cfg, recipe["variant"], "pick"), slots(cfg, recipe["variant"], "place")
    n = min(a.cycles, len(picks))
    results = []
    try:
        robot.connect()
        cell.load(recipe)
        cell.home()
        for k in range(n):
            if mode == "mock":
                robot.world.cycle = k + 1
            res = cell.run_cycle(picks[k], places[k], "forward")
            results.append(res)
            print(f"cycle {res.cycle_id}: {res.final_status} {res.fail_state} {res.cycle_time_s:.2f}s")
        if a.return_trip:
            for k in range(n):
                res = cell.run_cycle(places[k], picks[k], "return")
                results.append(res)
                print(f"cycle {res.cycle_id} (về): {res.final_status} {res.fail_state} {res.cycle_time_s:.2f}s")
        cell.home()
    except KeyboardInterrupt:
        robot.stop()
        print("\nDừng theo yêu cầu (Ctrl+C) – đã gửi StopMotion.")
    except (SafetyViolation, RobotError) as e:
        robot.stop()
        print(f"\nDỪNG AN TOÀN: {e}")
    finally:
        robot.close()
        if cam:
            cam.release()
    ok = sum(r.final_status == "PASS" for r in results)
    print(f"Kết quả: {ok}/{len(results)} PASS  – log: {log.path}")
    return results


if __name__ == "__main__":
    main()
