"""Know-how source #2: the operator hand-guides the FR5 (drag teach) while the controller
records the trajectory (TPD), then the robot replays it. Adapted from example/TestTPDCommand.py.

    python -m robot.teach_tpd record --name demo_B_expert --seconds 15
    python -m robot.teach_tpd replay --name demo_B_expert --ovl 20      # replay slowly first!
    python -m robot.teach_tpd delete --name demo_B_expert

Safety: replay is capped at safety.max_vel_pct; first replay should use --ovl 10–20 with a hand on
the E-stop. Recording samples joint positions every 2 ms (type=1).
Compare the recorded trajectory with the numbers extract.py gets from the video (same demo).
"""
from __future__ import annotations

import argparse
import time

from common.config import load_config


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["record", "replay", "delete"])
    ap.add_argument("--name", required=True)
    ap.add_argument("--seconds", type=float, default=15)
    ap.add_argument("--period-ms", type=int, default=2, choices=[2, 4, 8])
    ap.add_argument("--ovl", type=float, default=20)
    a = ap.parse_args()
    cfg = load_config()
    if cfg["robot"]["mode"] == "mock":
        raise SystemExit("teach_tpd cần robot thật hoặc simulator (robot.mode = sim|real)")
    from fairino import Robot
    ip = cfg["robot"]["ip_real"] if cfg["robot"]["mode"] == "real" else cfg["robot"]["ip_sim"]
    rpc = Robot.RPC(ip)
    try:
        if a.action == "record":
            rpc.Mode(1)                    # manual mode
            rpc.DragTeachSwitch(1)
            rpc.SetTPDParam(a.name, a.period_ms)
            input("Người thao tác cầm tay robot. Enter để BẮT ĐẦU ghi...")
            err = rpc.SetTPDStart(a.name, a.period_ms)
            print("đang ghi", a.seconds, "s ... (err", err, ")")
            time.sleep(a.seconds)
            rpc.SetWebTPDStop()
            rpc.DragTeachSwitch(0)
            print("đã lưu quỹ đạo", a.name)
        elif a.action == "replay":
            ovl = min(a.ovl, cfg["safety"]["max_vel_pct"])
            rpc.Mode(0)                    # auto mode
            rpc.LoadTPD(a.name)
            err, start = rpc.GetTPDStartPose(a.name)
            input(f"Robot sẽ tới điểm đầu {start} rồi phát lại ở {ovl}% – Enter để chạy (tay trên E-stop)")
            rpc.MoveCart(start, cfg["robot"]["tool"], 0, vel=min(20, ovl))
            print("MoveTPD err", rpc.MoveTPD(a.name, 1, ovl))
        else:
            print("SetTPDDelete err", rpc.SetTPDDelete(a.name))
    except KeyboardInterrupt:
        rpc.StopMotion()
    finally:
        try:
            rpc.DragTeachSwitch(0)
        except Exception:
            pass
        rpc.CloseRPC()


if __name__ == "__main__":
    main()
