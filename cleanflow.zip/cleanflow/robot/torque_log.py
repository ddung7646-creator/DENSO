"""Joint-torque monitoring: baseline + delta (upgraded from do_luc.py / monitor_torque()).

Fixes vs. the drawing-robot code:
  * no stray `break` (old monitor thread read the torque once and exited),
  * no busy loop (`time.sleep(0)`), fixed sample rate from config,
  * baseline taken at the pose where it is used (torque depends strongly on pose),
  * samples kept in memory during a motion, written to disk after the cycle,
  * no second thread sending commands (xmlrpc is not thread-safe): the watch is polled from
    FairinoRobot.wait_motion(), which issues StopMotion itself.

CLI (live view, replaces do_luc.py and joint_torque.py):
    python -m robot.torque_log --seconds 30 --csv logs/torque_live.csv
"""
from __future__ import annotations

import argparse
import csv
import time

import numpy as np


class TorqueWatch:
    def __init__(self, robot, joints=(1, 2, 3), threshold_nm: float | None = None):
        self.robot = robot
        self.idx = [j - 1 for j in joints]
        self.threshold = threshold_nm
        self.base: np.ndarray | None = None
        self.samples: list[tuple[float, float]] = []   # (t, delta)
        self.peak = 0.0
        self.tripped = False
        self._t0 = time.time()

    def take_baseline(self, n: int = 20, hz: float = 100.0):
        vals = []
        for _ in range(n):
            vals.append(np.asarray(self.robot.joint_torques(), float)[self.idx])
            time.sleep(1.0 / hz)
        self.base = np.median(vals, axis=0)
        self.samples.clear()
        self.peak, self.tripped, self._t0 = 0.0, False, time.time()
        return self.base

    def delta(self) -> float:
        if self.base is None:
            raise RuntimeError("chưa lấy baseline")
        cur = np.asarray(self.robot.joint_torques(), float)[self.idx]
        return float(np.max(np.abs(cur - self.base)))

    def poll(self) -> bool:
        """Call every control cycle. True = threshold exceeded → caller must stop."""
        d = self.delta()
        self.samples.append((time.time() - self._t0, d))
        self.peak = max(self.peak, d)
        if self.threshold is not None and d > self.threshold:
            self.tripped = True
            return True
        return False


def _live(cfg, seconds, csv_path):
    from robot.fr5 import make_robot
    robot = make_robot(cfg)
    robot.connect()
    tc = cfg["torque"]
    w = TorqueWatch(robot, tc["joints"])
    print("Đang lấy baseline – đừng chạm vào robot...")
    w.take_baseline(tc["baseline_samples"], tc["sample_hz"])
    print("baseline:", np.round(w.base, 3))
    rows = []
    t_end = time.time() + seconds
    try:
        while time.time() < t_end:
            tq = robot.joint_torques()
            d = w.delta()
            rows.append([time.time(), *tq, d])
            print(f"\rΔ={d:6.3f} Nm  " + " ".join(f"J{i+1}={v:7.3f}" for i, v in enumerate(tq)), end="")
            time.sleep(1.0 / tc["sample_hz"])
    except KeyboardInterrupt:
        pass
    finally:
        robot.close()
    print()
    if csv_path:
        with open(csv_path, "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(["t", "J1", "J2", "J3", "J4", "J5", "J6", "delta_max"])
            wr.writerows(rows)
        print("đã lưu", csv_path)


if __name__ == "__main__":
    from common.config import load_config
    ap = argparse.ArgumentParser()
    ap.add_argument("--seconds", type=float, default=30)
    ap.add_argument("--csv")
    a = ap.parse_args()
    _live(load_config(), a.seconds, a.csv)
