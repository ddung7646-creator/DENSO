"""Run:  python -m pytest -q   (from the cleanflow/ folder). No robot, camera or model needed."""
import copy
import subprocess
from pathlib import Path

import cv2
import numpy as np
import pytest

from common.config import load_config, load_recipe, slots, validate_recipe, ConfigError
from common.geometry import plan_z
from robot.cell import Cell, CycleLogger
from robot.fr5 import MockRobot, MockWorld, SafetyViolation

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def cfg():
    c = load_config()
    c["robot"]["mode"] = "mock"
    return c


# ------------------------------------------------------------------ geometry / recipes
def test_seed_recipes_valid(cfg):
    for v in "ABC":
        r = load_recipe(v, cfg)
        z = plan_z(r, cfg)
        assert z.travel > z.grip_pick + r["grip"]["depth_from_head_top_mm"]


def test_grip_too_low_rejected(cfg):
    r = load_recipe("B", cfg)
    bad = copy.deepcopy(r)
    bad["grip"]["depth_from_head_top_mm"] = 9.0      # fingertips would hit the plate
    assert any("chạm mặt đế" in e for e in validate_recipe(bad, cfg))


def test_speed_cap_rejected(cfg):
    r = copy.deepcopy(load_recipe("A", cfg))
    r["motion"]["insert_speed_pct"] = 50
    assert validate_recipe(r, cfg)


# ------------------------------------------------------------------ cell with mock robot
def _cell(cfg, tmp_path, faults=None):
    cfg["gripper"]["empty_close_pct"] = 0.0
    robot = MockRobot(cfg, MockWorld(faults or {}))
    cell = Cell(robot, cfg, CycleLogger(str(tmp_path)))
    cell.load(load_recipe("B", cfg))
    return robot, cell


def test_cycle_pass(cfg, tmp_path):
    robot, cell = _cell(cfg, tmp_path)
    robot.world.cycle = 1
    r = cell.run_cycle(slots(cfg, "B", "pick")[0], slots(cfg, "B", "place")[0])
    assert r.final_status == "PASS" and r.pick_verified is True
    assert (tmp_path / "cycles.csv").read_text().count("\n") == 2


def test_missed_grasp_retried_then_fail(cfg, tmp_path):
    robot, cell = _cell(cfg, tmp_path, {"miss_grasp": {1}})
    robot.world.cycle = 1
    r = cell.run_cycle(slots(cfg, "B", "pick")[0], slots(cfg, "B", "place")[0])
    assert r.final_status == "FAIL" and r.fail_state == "MISS_GRASP" and r.retry_count == 1


def test_jam_returns_screw_to_pick_hole(cfg, tmp_path):
    robot, cell = _cell(cfg, tmp_path, {"jam_insert": {1}})
    robot.world.cycle = 1
    pick = slots(cfg, "B", "pick")[0]
    r = cell.run_cycle(pick, slots(cfg, "B", "place")[0])
    assert r.final_status == "FAIL" and r.fail_state == "JAM"
    assert ("stop",) in robot.trace
    moves = [t for t in robot.trace if t[0] == "move"]
    last_down = [m for m in moves if m[1][0] == pick.x and m[1][2] < 10]
    assert last_down, "screw must be put back into the pick hole"
    assert robot.trace[-2][0] == "gripper"            # released there, then lifted


def test_safety_blocks_out_of_workspace(cfg):
    robot = MockRobot(cfg)
    with pytest.raises(SafetyViolation):
        robot.move_l((600, 100, 50), 20)
    with pytest.raises(SafetyViolation):
        robot.move_l((100, 100, 0.5), 20)             # below z_min


def test_speed_and_force_clamped(cfg):
    robot = MockRobot(cfg)
    robot.move_l((100, 100, 50), 99)
    assert robot.trace[-1][2] == cfg["safety"]["max_vel_pct"]
    robot.gripper(5, 99)
    assert robot.trace[-1][2] == cfg["safety"]["max_grip_force_pct"]


# ------------------------------------------------------------------ vision on the printed board
@pytest.fixture(scope="module")
def board_img():
    pdf = ROOT / "tools" / "cleanflow_board_A3.pdf"
    out = Path("/tmp/_board_test")
    subprocess.run(["pdftoppm", "-r", "150", "-png", "-singlefile", str(pdf), str(out)], check=True)
    return cv2.imread(str(out) + ".png")


def test_homography_on_board(cfg, board_img):
    from vision.board import BoardView
    v = BoardView(cfg, board_img)
    assert v.n_markers == 4
    s = slots(cfg, "A", "pick")[0]
    px = v.to_image([[s.x, s.y]])[0]
    back = v.to_board([px])[0]
    assert np.allclose(back, [s.x, s.y], atol=0.3)
    # page geometry: 150 dpi, board origin at page (30, 268.5) mm from top-left
    ppm = 150 / 25.4
    expect = [(30 + s.x) * ppm, (297 - 28.5 - s.y) * ppm]
    assert np.allclose(px, expect, atol=2.0)


def _draw_screw(img, view, center, length, width):
    cx, cy = center
    poly = view.to_image([[cx - length / 2, cy - width / 2], [cx + length / 2, cy - width / 2],
                          [cx + length / 2, cy + width / 2], [cx - length / 2, cy + width / 2]])
    cv2.fillPoly(img, [poly.astype(np.int32)], (40, 40, 40))


def test_identify_variant(cfg, board_img):
    from common.config import recipes_available
    from vision.board import BoardView
    from vision.identify import measure, classify
    cfg["camera"]["height_mm"] = 1e9                  # flat synthetic image: no parallax
    recipes = recipes_available(cfg)
    for v in "AB":
        img = board_img.copy()
        view = BoardView(cfg, img)
        p = recipes[v]["part"]
        _draw_screw(img, view, cfg["board"]["identify_slot"]["center"], p["length_mm"], p["head_d_mm"])
        got, info = classify(measure(img, cfg), recipes)
        assert got == v, info
    assert classify(measure(board_img.copy(), cfg), recipes)[0] is None   # empty slot


def test_verify_placement(cfg, board_img):
    from vision.verify import PlacementVerifier
    pv = PlacementVerifier(None, cfg)
    pv.capture_reference(board_img.copy())
    img = board_img.copy()
    q1, q2 = slots(cfg, "B", "place")[:2]
    u, v = pv.view.to_image([[q1.x, q1.y]])[0]
    cv2.circle(img, (int(u), int(v)), 20, (30, 30, 30), -1)
    assert pv(q1, img) is True
    assert pv(q2, img) is False


# ------------------------------------------------------------------ video features
def _synthetic_demo(cfg, n=3, fps=60.0):
    from common.config import slots as S
    picks, places = S(cfg, "B", "pick"), S(cfg, "B", "place")
    t, mid, ap = [], [], []
    tt = 0.0
    home = np.array([180.0, 40.0])

    def seg(a, b, dur, aperture, slow_last=0.0):
        nonlocal tt
        k = int(dur * fps)
        for i in range(k):
            u = i / k
            # fast then slow: cover 1-slow_last of the way in 70 % of time
            if slow_last and u > 0.7:
                frac = (1 - slow_last) + slow_last * (u - 0.7) / 0.3
            elif slow_last:
                frac = (1 - slow_last) * u / 0.7
            else:
                frac = u
            t.append(tt); mid.append(a + (b - a) * frac)
            ap.append(aperture(u) if callable(aperture) else aperture)
            tt += 1 / fps

    for k in range(n):
        p = np.array([picks[k].x, picks[k].y]); q = np.array([places[k].x, places[k].y])
        seg(home, p, 1.0, 45.0, slow_last=0.15)          # approach, open hand
        seg(p, p, 0.25, lambda u: 45 - 30 * min(1, u * 3))  # close on the screw
        seg(p, p, 0.3, 15.0)                              # dwell (holding, not moving)
        seg(p, q, 1.2, 15.0, slow_last=0.1)               # transfer + slow insert
        seg(q, q, 0.25, lambda u: 15 + 30 * u)            # open
        seg(q, home, 0.8, 45.0)
    mid, ap = np.array(mid), np.array(ap)
    off = np.column_stack([ap / 2, np.zeros_like(ap)])
    return np.array(t), mid - off, mid + off, picks, places


def test_features_detect_reps(cfg):
    from vision.features import analyse, summarize, recipe_draft
    t, th, ix, picks, places = _synthetic_demo(cfg)
    reps = analyse(t, th, ix, picks, places, fps=60)
    assert [r["pick_slot"] for r in reps] == ["PB1", "PB2", "PB3"]
    assert [r["place_slot"] for r in reps] == ["QB1", "QB2", "QB3"]
    s = summarize(reps)
    assert 0.2 <= s["dwell_s"]["median"] <= 0.5
    assert s["approach_ratio"]["median"] < 0.5
    draft = recipe_draft(load_recipe("B", cfg), s, cfg, "video:test", grip_depth_mm=5.0)
    assert validate_recipe(draft, cfg) == []
    assert draft["provenance"]["grip.dwell_s"].startswith("measured")
