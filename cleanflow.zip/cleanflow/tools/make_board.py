"""Generate the 1:1 A3 base-plate template (ArUco markers + jig drill map) FROM config.yaml.

Change geometry in config.yaml, then:  python tools/make_board.py  → tools/cleanflow_board_A3.pdf

Board frame (mm): origin = centre of marker ID3 (bottom-left, robot side),
+X toward ID2 (bottom-right), +Y toward ID0 (top-left), Z up.
"""
import io
import os
import sys
from pathlib import Path

import cv2
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.config import load_config  # noqa: E402

FONT_CANDIDATES = [  # need Vietnamese glyphs
    ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
    ("/Library/Fonts/Arial Unicode.ttf", "/Library/Fonts/Arial Unicode.ttf"),
]
for reg, bold in FONT_CANDIDATES:
    if os.path.exists(reg):
        pdfmetrics.registerFont(TTFont("DV", reg)); pdfmetrics.registerFont(TTFont("DVB", bold))
        break
else:
    raise SystemExit("không tìm thấy font hỗ trợ tiếng Việt – sửa FONT_CANDIDATES")

CFG = load_config()
OUT = Path(CFG["_root"]) / "tools" / "cleanflow_board_A3.pdf"
PAGE_W, PAGE_H = 420, 297            # A3 landscape, mm
MARKER = CFG["board"]["marker_size_mm"]
markers = {int(k): tuple(v) for k, v in CFG["board"]["marker_centers_mm"].items()}
DX = max(v[0] for v in markers.values()); DY = max(v[1] for v in markers.values())
OX, OY = (PAGE_W - DX) / 2, (PAGE_H - DY) / 2   # page position of board origin (ID3 centre)
names = {0: "góc trên-trái", 1: "góc trên-phải", 2: "góc dưới-phải", 3: "góc dưới-trái (GỐC 0,0)"}
J = CFG["jigs"]
PITCH, COLS = J["pitch_mm"], J["cols"]
rows = [(v, v, r["y_mm"], r["pick_d_mm"], r["place_d_mm"], r["depth_mm"]) for v, r in J["rows"].items()]
PICK_X0, PLACE_X0 = J["pick"]["x0_mm"], J["place"]["x0_mm"]
ID_SLOT = CFG["board"]["identify_slot"]


def P(x, y):  # board mm -> page points
    return (OX + x) * mm, (OY + y) * mm


def marker_png(i):
    img = cv2.aruco.generateImageMarker(cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50), i, 600)
    ok, buf = cv2.imencode(".png", img)
    return ImageReader(io.BytesIO(buf.tobytes()))


def hole(c, x, y, d, label):
    cx, cy = P(x, y)
    c.setLineWidth(0.25)
    c.circle(cx, cy, d / 2 * mm)
    L = 4 * mm
    c.line(cx - L, cy, cx + L, cy); c.line(cx, cy - L, cx, cy + L)
    c.setFont("DV", 5.5)
    c.drawCentredString(cx, cy - 6.5 * mm, label)


c = canvas.Canvas(str(OUT), pagesize=(PAGE_W * mm, PAGE_H * mm))
c.setTitle("CleanFlow base plate A3 1:1")

# markers
for i, (x, y) in markers.items():
    cx, cy = P(x, y)
    h = MARKER / 2 * mm
    c.drawImage(marker_png(i), cx - h, cy - h, MARKER * mm, MARKER * mm)
    c.setFont("DV", 6.5)
    lab = f"ID {i} | {names[i]} | tâm ({x:.0f}, {y:.0f})"
    if y > 0:
        tx = cx + h + 3 * mm if x == 0 else cx - h - 3 * mm
        (c.drawString if x == 0 else c.drawRightString)(tx, cy - 1 * mm, lab)
    else:
        ty = cy + h + 3 * mm
        (c.drawString if x == 0 else c.drawRightString)(cx - h if x == 0 else cx + h, ty, lab)

# axes at origin
ox, oy = P(0, 0)
c.setLineWidth(0.6)
c.line(ox + 24 * mm, oy, ox + 44 * mm, oy); c.drawString(ox + 45 * mm, oy - 1 * mm, "+X")
c.setFont("DV", 6.5)
c.line(ox, oy + 30 * mm, ox, oy + 50 * mm); c.drawString(ox - 2 * mm, oy + 52 * mm, "+Y")

# jigs
for title, x0, idx in (("ĐỒ GÁ LẤY (pick) – lỗ rộng", PICK_X0, 3), ("ĐỒ GÁ ĐẶT (place) – lỗ chặt", PLACE_X0, 4)):
    xa, ya = P(x0 - 25, 165); xb, yb = P(x0 + PITCH * (COLS - 1) + 15, 75)
    c.setDash(3, 2); c.setLineWidth(0.3); c.rect(xa, yb, xb - xa, ya - yb); c.setDash()
    c.setFont("DVB", 8); c.drawString(xa, ya + 2 * mm, title)
    for v, name, y, dpick, dplace, depth in rows:
        d = dpick if idx == 3 else dplace
        lx, ly = P(x0 - 24, y)
        c.setFont("DVB", 6.5); c.drawString(lx, ly + 1.5 * mm, v); c.setFont("DV", 6); c.drawString(lx, ly - 2.5 * mm, f"Ø{d:.1f}"); c.drawString(lx, ly - 5.5 * mm, f"sâu {depth:.0f}")
        for k in range(COLS):
            hole(c, x0 + k * PITCH, y, d, f"{'P' if idx == 3 else 'Q'}{v}{k + 1}")

# identification slot
sx, sy = ID_SLOT["center"]; s = ID_SLOT["size"]
xa, ya = P(sx - s / 2, sy - s / 2)
c.setLineWidth(0.8); c.rect(xa, ya, s * mm, s * mm)
c.setFont("DVB", 8); c.drawCentredString(*P(sx, sy + s / 2 + 3), "Ô NHẬN DIỆN")
c.setFont("DV", 5.5); c.drawCentredString(*P(sx, sy - s / 2 - 5), "đặt ốc nằm ngang,")
c.drawCentredString(*P(sx, sy - s / 2 - 8.5), "nền tương phản")

# scale bars (check both axes)
def hbar(x, y, length):
    a = P(x, y); b = P(x + length, y)
    c.setLineWidth(0.5); c.line(a[0], a[1], b[0], a[1])
    for t in range(0, int(length) + 1, 10):
        tx = P(x + t, y)[0]; c.line(tx, a[1], tx, a[1] + (2.5 if t % 50 else 4) * mm)
    c.setFont("DV", 6); c.drawString(b[0] + 2 * mm, a[1], f"{length:.0f} mm")

def vbar(x, y, length):
    a = P(x, y); b = P(x, y + length)
    c.setLineWidth(0.5); c.line(a[0], a[1], a[0], b[1])
    for t in range(0, int(length) + 1, 10):
        ty = P(x, y + t)[1]; c.line(a[0], ty, a[0] + (2.5 if t % 50 else 4) * mm, ty)
    c.setFont("DV", 6); c.drawString(a[0] - 3 * mm, b[1] + 2 * mm, f"{length:.0f} mm")

hbar(130, 35, 100)
vbar(350, 60, 100)

# header / instructions
c.setFont("DVB", 10)
c.drawString(*P(40, 222), "CleanFlow – Tấm đế 1:1 (A3)  |  ArUco DICT_4X4_50, cạnh 40 mm")
c.setFont("DV", 6.8)
lines = [
    "1) In A3 ngang, 'Actual size / 100%'. Đo 2 thước: ngang và dọc đều phải đúng 100 mm (sai ≤ 0,5 mm).",
    "2) Dán cả tờ lên tấm đế ≥ 45×32 cm. Chấm dấu tâm lỗ bằng đinh/mũi đột rồi khoan xuyên qua giấy.",
    "3) Tọa độ trong config.yaml tính theo khung này: gốc = tâm ID3, +X → ID2, +Y → ID0. Đơn vị mm.",
]
for k, t in enumerate(lines):
    c.drawString(*P(40, 214 - k * 4), t)
c.showPage(); c.save()

print("đã tạo", OUT)
