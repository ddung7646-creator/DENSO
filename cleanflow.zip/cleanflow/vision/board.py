"""Board frame ↔ image: ArUco detection, homography, top-down warp, parallax correction.

Marker corners are known exactly (printed 1:1 from tools/make_board.py): OpenCV returns corners
in the order TL, TR, BR, BL of the marker as printed; on the board +Y points toward ID0 ("up").
"""
from __future__ import annotations

import cv2
import numpy as np


def _dict(cfg):
    return cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, cfg["board"]["aruco_dictionary"]))


def marker_corners_board(cfg) -> dict[int, np.ndarray]:
    h = cfg["board"]["marker_size_mm"] / 2
    out = {}
    for i, (cx, cy) in cfg["board"]["marker_centers_mm"].items():
        out[int(i)] = np.array([[cx - h, cy + h], [cx + h, cy + h], [cx + h, cy - h], [cx - h, cy - h]], np.float32)
    return out


def detect(img, cfg):
    gray = img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    det = cv2.aruco.ArucoDetector(_dict(cfg), cv2.aruco.DetectorParameters())
    corners, ids, _ = det.detectMarkers(gray)
    found = {}
    if ids is not None:
        known = marker_corners_board(cfg)
        for c, i in zip(corners, ids.flatten()):
            if int(i) in known:
                found[int(i)] = c[0].astype(np.float32)
    return found


class BoardView:
    """Homography image→board (mm). Needs ≥1 marker (4 corners); 4 markers = best accuracy."""

    def __init__(self, cfg, img=None, H=None):
        self.cfg = cfg
        self.H = H
        if img is not None:
            self.fit(img)

    def fit(self, img):
        found = detect(img, self.cfg)
        if not found:
            raise RuntimeError("không thấy marker ArUco nào của tấm đế")
        known = marker_corners_board(self.cfg)
        src = np.concatenate([found[i] for i in found])
        dst = np.concatenate([known[i] for i in found])
        self.H, _ = cv2.findHomography(src, dst, cv2.RANSAC if len(found) > 1 else 0, 2.0)
        self.n_markers = len(found)
        self.image_size = img.shape[1], img.shape[0]
        return self

    def to_board(self, pts_px) -> np.ndarray:
        p = np.asarray(pts_px, np.float64).reshape(-1, 1, 2)
        return cv2.perspectiveTransform(p, self.H).reshape(-1, 2)

    def to_image(self, pts_mm) -> np.ndarray:
        p = np.asarray(pts_mm, np.float64).reshape(-1, 1, 2)
        return cv2.perspectiveTransform(p, np.linalg.inv(self.H)).reshape(-1, 2)

    def nadir(self) -> np.ndarray:
        """Board point under the image centre (≈ under the lens for a top-down camera)."""
        w, h = self.image_size
        return self.to_board([[w / 2, h / 2]])[0]

    def correct_height(self, pts_mm, height_mm: float) -> np.ndarray:
        """A point `height_mm` above the plate projects outward from the nadir; pull it back."""
        H = self.cfg["camera"]["height_mm"]
        c = self.nadir()
        pts = np.asarray(pts_mm, float)
        return c + (pts - c) * (H - height_mm) / H

    def warp(self, img, x0, x1, y0, y1, px_per_mm=None):
        """Top-down crop of board region [x0,x1]×[y0,y1]; pixel (u,v) ↔ (x0+u/s, y1-v/s)."""
        s = px_per_mm or self.cfg["camera"]["px_per_mm_topdown"]
        A = np.array([[s, 0, -s * x0], [0, -s, s * y1], [0, 0, 1]], float)   # board → crop pixels
        M = A @ self.H
        size = (int(round((x1 - x0) * s)), int(round((y1 - y0) * s)))
        return cv2.warpPerspective(img, M, size), s
