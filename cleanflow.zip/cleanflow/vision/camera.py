"""Live camera (USB webcam, or phone via DroidCam/Iriun which appears as a webcam)."""
from __future__ import annotations

import time

import cv2


class Camera:
    def __init__(self, cfg, width=1920, height=1080):
        self.cap = cv2.VideoCapture(cfg["camera"]["index"])
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        if not self.cap.isOpened():
            raise RuntimeError(f"không mở được camera index {cfg['camera']['index']}")

    def grab(self, flush: int = 5):
        """Return a fresh frame (drop buffered frames first – webcams buffer old images)."""
        for _ in range(flush):
            self.cap.grab()
        ok, frame = self.cap.read()
        if not ok:
            time.sleep(0.2)
            ok, frame = self.cap.read()
        if not ok:
            raise RuntimeError("không đọc được ảnh từ camera")
        return frame

    def release(self):
        self.cap.release()
