"""Video of a human demo (top camera) → fingertip tracks → know-how numbers → recipe draft.

Uses the MediaPipe **Tasks** API (HandLandmarker). mediapipe 0.10.31 has NO `mp.solutions`,
so tutorials using mp.solutions.hands will fail. Download the model once:
  https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
  → save as models/hand_landmarker.task

    python -m vision.extract --video demos/B_expert_top.mp4 --variant B \
        --grip-depth-mm 5.0 --out recipes/B.yaml
    python -m vision.extract --video demos/B_novice_top.mp4 --variant B --reps-only   # compare people

Outputs: <video>_reps.csv (one row per rep), <video>_tracks.csv (per frame), recipe draft YAML.
Protocol (see CONTEXT.md): camera fixed, 4 markers visible, pinch with thumb + index only,
one hand, 10 reps, clap/LED at start for syncing with the side camera.
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import cv2
import numpy as np
import yaml

from common.config import load_config, load_recipe, slots
from vision.board import BoardView
from vision.features import analyse, summarize, recipe_draft

THUMB_TIP, INDEX_TIP = 4, 8


def fit_board(cap, cfg, frames=30):
    Hs, view = [], None
    for _ in range(frames):
        ok, img = cap.read()
        if not ok:
            break
        try:
            v = BoardView(cfg, img)
            if v.n_markers >= 3:
                Hs.append(v.H / v.H[2, 2]); view = v
        except RuntimeError:
            pass
    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
    if view is None:
        raise RuntimeError("không thấy đủ ≥3 marker trong 30 frame đầu – chỉnh camera cho thấy cả 4 góc")
    view.H = np.median(Hs, axis=0)
    return view


def track(video, cfg, model, hand_height_mm):
    import mediapipe as mp
    from mediapipe.tasks import python as mpp
    from mediapipe.tasks.python import vision as mpv

    cap = cv2.VideoCapture(str(video))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    view = fit_board(cap, cfg)
    opts = mpv.HandLandmarkerOptions(
        base_options=mpp.BaseOptions(model_asset_path=str(model)),
        running_mode=mpv.RunningMode.VIDEO, num_hands=1,
        min_hand_detection_confidence=0.5, min_hand_presence_confidence=0.5, min_tracking_confidence=0.5)
    t, th, ix = [], [], []
    with mpv.HandLandmarker.create_from_options(opts) as lm:
        k = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            h, w = frame.shape[:2]
            ts = int(round(k * 1000.0 / fps))
            res = lm.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB,
                                               data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)), ts)
            if res.hand_landmarks:
                L = res.hand_landmarks[0]
                px = [[L[THUMB_TIP].x * w, L[THUMB_TIP].y * h], [L[INDEX_TIP].x * w, L[INDEX_TIP].y * h]]
                mm = view.correct_height(view.to_board(px), hand_height_mm)
                th.append(mm[0]); ix.append(mm[1])
            else:
                th.append([np.nan, np.nan]); ix.append([np.nan, np.nan])
            t.append(k / fps)
            k += 1
    cap.release()
    return np.array(t), np.array(th), np.array(ix), fps, view.n_markers


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--variant", required=True)
    ap.add_argument("--model", default=str(Path(__file__).resolve().parents[1] / "models" / "hand_landmarker.task"))
    ap.add_argument("--base-recipe", help="mặc định recipes/<variant>.yaml")
    ap.add_argument("--grip-depth-mm", type=float, help="khoảng cách đỉnh đầu ốc → tâm đầu ngón (camera ngang/Kinovea)")
    ap.add_argument("--hand-height-mm", type=float, default=10.0, help="độ cao đầu ngón khi kẹp, để hiệu chỉnh thị sai")
    ap.add_argument("--reverse", action="store_true", help="demo đi từ đồ gá đặt về đồ gá lấy")
    ap.add_argument("--out", help="nơi ghi recipe nháp (mặc định <video>_recipe.yaml)")
    ap.add_argument("--reps-only", action="store_true")
    a = ap.parse_args()

    cfg = load_config()
    if not Path(a.model).exists():
        raise SystemExit(f"thiếu model {a.model} – xem hướng dẫn tải ở đầu file")
    t, th, ix, fps, nm = track(a.video, cfg, a.model, a.hand_height_mm)
    stem = Path(a.video).with_suffix("")
    with open(f"{stem}_tracks.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["t", "thumb_x", "thumb_y", "index_x", "index_y"])
        w.writerows(np.column_stack([t, th, ix]).round(3))

    picks, places = slots(cfg, a.variant, "pick"), slots(cfg, a.variant, "place")
    if a.reverse:
        picks, places = places, picks
    reps = analyse(t, th, ix, picks, places, fps)
    if not reps:
        raise SystemExit("không tách được lần gắp–đặt nào: kiểm tra tay có bị che, ngón có chụm lại khi cầm ốc")
    with open(f"{stem}_reps.csv", "w", newline="") as f:
        w = csv.DictWriter(f, reps[0].keys()); w.writeheader(); w.writerows(reps)
    summ = summarize(reps)
    print(f"{len(reps)} lần gắp–đặt, {nm} marker, {fps:.0f} fps")
    for k, v in summ.items():
        if isinstance(v, dict):
            print(f"  {k:24s} median={v['median']:<8} IQR={v['iqr']}")
    if a.reps_only:
        return
    base = load_recipe(a.base_recipe or a.variant, cfg)
    draft = recipe_draft(base, summ, cfg, source=f"video:{Path(a.video).name}", grip_depth_mm=a.grip_depth_mm)
    out = a.out or f"{stem}_recipe.yaml"
    with open(out, "w", encoding="utf-8") as f:
        f.write("# Recipe NHÁP sinh từ video – người thao tác duyệt/chỉnh rồi tăng recipe_version\n")
        yaml.safe_dump(draft, f, allow_unicode=True, sort_keys=False)
    print("recipe nháp →", out)


if __name__ == "__main__":
    main()
