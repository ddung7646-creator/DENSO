"""Turn fingertip tracks (board mm, top camera) into know-how numbers and a recipe draft.

Pure numpy/scipy – testable without video. Inputs are per-frame thumb-tip (landmark 4) and
index-tip (landmark 8) positions in board mm, NaN when the hand is not detected.

Events: the pinch aperture |thumb-index| drops and stays low while the part is held.
  grasp  = start of a closed segment near a pick hole
  release = end of that segment near a place hole
Everything the top view cannot see (vertical grip point on the screw) comes from the side camera
or is entered manually (Kinovea) and is marked as such in the recipe's provenance.
"""
from __future__ import annotations

import copy

import numpy as np
from scipy.signal import savgol_filter


def _fill_nan(a: np.ndarray, max_gap: int) -> np.ndarray:
    a = a.copy()
    for col in range(a.shape[1]):
        y = a[:, col]
        bad = np.isnan(y)
        if bad.all():
            continue
        idx = np.arange(len(y))
        y[bad] = np.interp(idx[bad], idx[~bad], y[~bad])
        # re-blank long gaps
        run = 0
        for i, b in enumerate(bad):
            run = run + 1 if b else 0
            if run > max_gap:
                y[i - run + 1:i + 1] = np.nan
        a[:, col] = y
    return a


def _smooth(x, fps, window_s=0.15):
    w = max(5, int(round(window_s * fps)) | 1)
    if len(x) <= w:
        return x
    out = x.copy()
    ok = ~np.isnan(x).any(axis=1) if x.ndim == 2 else ~np.isnan(x)
    for s, e in _segments(ok):          # smooth each valid run separately
        if e - s > w:
            out[s:e] = savgol_filter(x[s:e], w, 2, axis=0)
    return out


def _segments(mask: np.ndarray):
    """(start, end_exclusive) of True runs."""
    d = np.diff(np.concatenate([[0], mask.astype(int), [0]]))
    return list(zip(np.where(d == 1)[0], np.where(d == -1)[0]))


def _nearest(pt, slots, max_mm):
    best, dist = None, 1e9
    for s in slots:
        d = float(np.hypot(pt[0] - s.x, pt[1] - s.y))
        if d < dist:
            best, dist = s, d
    return (best, dist) if dist <= max_mm else (None, dist)


def analyse(t, thumb, index, pick_slots, place_slots, fps=None, slot_radius_mm=20.0,
            min_hold_s=0.3, slow_frac=0.3):
    t = np.asarray(t, float)
    fps = fps or 1.0 / np.median(np.diff(t))
    th = _smooth(_fill_nan(np.asarray(thumb, float), int(0.2 * fps)), fps)
    ix = _smooth(_fill_nan(np.asarray(index, float), int(0.2 * fps)), fps)
    ap = np.linalg.norm(th - ix, axis=1)
    mid = (th + ix) / 2
    vel = np.full(len(t), np.nan)
    vel[1:] = np.linalg.norm(np.diff(mid, axis=0), axis=1) * fps
    vel = np.where(np.isnan(vel), np.nan, vel)

    valid = ~np.isnan(ap)
    lo, hi = np.nanpercentile(ap, 5), np.nanpercentile(ap, 90)
    closed_thr = lo + 0.35 * (hi - lo)
    closed = valid & (ap < closed_thr)

    reps, prev_end = [], 0
    for s, e in _segments(closed):
        if (t[e - 1] - t[s]) < min_hold_s:
            continue
        pk, dpk = _nearest(mid[s], pick_slots, slot_radius_mm)
        pl, dpl = _nearest(mid[e - 1], place_slots, slot_radius_mm)
        if pk is None or pl is None:
            continue
        win = (t >= t[s] - 0.8) & (t <= t[s])
        pre_open = float(np.nanmax(ap[win])) if win.any() else np.nan
        closed_ap = float(np.nanmedian(ap[s:e]))

        # approach phase: from previous release to grasp
        a_idx = np.arange(prev_end, s)
        v_app = vel[a_idx] if len(a_idx) else np.array([np.nan])
        peak_app = float(np.nanmax(v_app)) if np.isfinite(v_app).any() else np.nan
        slow_start = s
        for i in range(s - 1, prev_end - 1, -1):
            if vel[i] > slow_frac * peak_app:
                slow_start = i + 1
                break
        slow_zone = float(np.hypot(*(mid[slow_start] - np.array([pk.x, pk.y]))))
        app_ratio = float(np.nanmedian(vel[slow_start:s]) / peak_app) if s > slow_start and peak_app > 0 else np.nan

        # hold phase: dwell after grasp, transfer peak, insertion (slow end part)
        h_idx = np.arange(s, e)
        v_hold = vel[h_idx]
        peak_tr = float(np.nanmax(v_hold))
        move = np.where(v_hold > 20.0)[0]
        dwell = float(t[s + move[0]] - t[s]) if len(move) else np.nan
        ins_start = e - 1
        for i in range(e - 1, s, -1):
            if vel[i] > slow_frac * peak_tr:
                ins_start = i + 1
                break
        ins_ratio = float(np.nanmedian(vel[ins_start:e]) / peak_tr) if e > ins_start and peak_tr > 0 else np.nan

        reps.append({
            "rep": len(reps) + 1, "t_grasp_s": round(t[s], 3), "t_release_s": round(t[e - 1], 3),
            "pick_slot": pk.id, "place_slot": pl.id,
            "grasp_offset_mm": round(dpk, 2), "place_offset_mm": round(dpl, 2),
            "pre_grasp_aperture_mm": round(pre_open, 2), "closed_aperture_mm": round(closed_ap, 2),
            "approach_peak_mm_s": round(peak_app, 1), "slow_zone_mm": round(slow_zone, 1),
            "approach_ratio": round(app_ratio, 3), "dwell_s": round(dwell, 3),
            "transfer_peak_mm_s": round(peak_tr, 1), "insert_ratio": round(ins_ratio, 3),
            "insert_duration_s": round(t[e - 1] - t[ins_start], 3),
            "hold_duration_s": round(t[e - 1] - t[s], 3),
        })
        prev_end = e
    return reps


def summarize(reps: list[dict]) -> dict:
    keys = [k for k in reps[0] if isinstance(reps[0][k], float)] if reps else []
    out = {"n_reps": len(reps)}
    for k in keys:
        v = np.array([r[k] for r in reps], float)
        v = v[np.isfinite(v)]
        if len(v):
            out[k] = {"median": round(float(np.median(v)), 3),
                      "iqr": round(float(np.percentile(v, 75) - np.percentile(v, 25)), 3)}
    return out


def recipe_draft(base: dict, summary: dict, cfg: dict, source: str, grip_depth_mm: float | None = None) -> dict:
    """Override the measurable fields of `base`; record where each value came from."""
    r = copy.deepcopy(base)
    r.pop("_path", None)
    prov = {}
    s, m, g = cfg["safety"], r["motion"], r["grip"]

    def med(k):
        return summary.get(k, {}).get("median")

    width = r["part"]["head_d_mm"] if (grip_depth_mm or g["depth_from_head_top_mm"]) < r["part"]["head_height_mm"] \
        else r["part"]["shank_d_mm"]
    if med("pre_grasp_aperture_mm") and med("closed_aperture_mm"):
        # fingertip landmarks sit inside the finger pads: subtract the closed aperture (pad thickness)
        g["open_width_mm"] = round(min(cfg["gripper"]["stroke_mm"],
                                       max(width + 2.5, med("pre_grasp_aperture_mm") - med("closed_aperture_mm") + width)), 1)
        prov["grip.open_width_mm"] = "measured(video): pre-grasp aperture − closed aperture + part width"
    if med("dwell_s") is not None:
        g["dwell_s"] = round(float(np.clip(med("dwell_s"), 0.1, 1.0)), 2)
        prov["grip.dwell_s"] = "measured(video)"
    if grip_depth_mm is not None:
        g["depth_from_head_top_mm"] = round(grip_depth_mm, 1)
        prov["grip.depth_from_head_top_mm"] = "measured(side camera / Kinovea)"
    if med("slow_zone_mm") is not None:
        m["slow_zone_mm"] = round(float(np.clip(med("slow_zone_mm"), 5, m["clearance_mm"])), 1)
        prov["motion.slow_zone_mm"] = "measured(video, top view – horizontal deceleration distance)"
    if med("approach_ratio") is not None:
        m["approach_speed_pct"] = round(float(np.clip(m["transfer_speed_pct"] * med("approach_ratio"), 3, s["max_vel_pct"])), 1)
        prov["motion.approach_speed_pct"] = "measured ratio(video) × transfer_speed_pct"
    if med("insert_ratio") is not None:
        m["insert_speed_pct"] = round(float(np.clip(m["transfer_speed_pct"] * med("insert_ratio"), 2, s["max_insert_vel_pct"])), 1)
        prov["motion.insert_speed_pct"] = "measured ratio(video) × transfer_speed_pct"
    for k in ("grip.close_width_mm", "grip.force_pct", "motion.transfer_speed_pct", "motion.clearance_mm",
              "insert.jam_dtorque_nm"):
        prov.setdefault(k, "default/base recipe (tune: grip_sweep.py, torque logs)")
    r["source"] = source
    base_v = str(base.get("recipe_version", "0"))
    r["recipe_version"] = f"{base_v.split('-')[0]}-video"
    r["provenance"] = prov
    r["demo_stats"] = summary
    return r
