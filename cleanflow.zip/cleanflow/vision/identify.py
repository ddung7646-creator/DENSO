"""Identify which variant lies in the identification slot → choose its recipe automatically.

Classic OpenCV, no training data needed: warp the slot top-down (known mm/px), Otsu threshold with
automatic polarity, largest blob, min-area rectangle → length and max width in mm, nearest recipe
by (length_mm, head_d_mm). Part must lie flat inside the slot on a contrasting matte background.

    python -m vision.identify              # live camera, prints the variant
    python -m vision.identify --image x.jpg
"""
from __future__ import annotations

import argparse

import cv2
import numpy as np

from vision.board import BoardView


def measure(img, cfg, view: BoardView | None = None, margin_mm: float = 5.0):
    view = view or BoardView(cfg, img)
    (cx, cy), s = cfg["board"]["identify_slot"]["center"], cfg["board"]["identify_slot"]["size"]
    half = s / 2 - margin_mm            # stay inside the printed frame line
    crop, ppm = view.warp(img, cx - half, cx + half, cy - half, cy + half)
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    if np.mean(bw) > 127:               # background came out white → part is the dark class
        bw = 255 - bw
    bw = cv2.morphologyEx(bw, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    cnts, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)
    area_mm2 = cv2.contourArea(c) / ppm ** 2
    if area_mm2 < 5:                    # noise / empty slot
        return None
    (_, _), (w, h), _ = cv2.minAreaRect(c)
    length, width = max(w, h) / ppm, min(w, h) / ppm
    # parallax: the part's upper surface is ~ width/2 above the plate
    Hc = cfg["camera"]["height_mm"]
    k = (Hc - width / 2) / Hc
    return {"length_mm": round(length * k, 2), "width_mm": round(width * k, 2), "area_mm2": round(area_mm2 * k * k, 1),
            "markers_seen": getattr(view, "n_markers", None)}


def classify(meas, recipes: dict, tol_mm: float = 1.5):
    if meas is None:
        return None, {"reason": "ô nhận diện trống"}
    best, best_score = None, 1e9
    for v, r in recipes.items():
        p = r["part"]
        score = max(abs(meas["length_mm"] - p["length_mm"]), abs(meas["width_mm"] - p["head_d_mm"]))
        if score < best_score:
            best, best_score = v, score
    info = dict(meas, error_mm=round(best_score, 2))
    return (best if best_score <= tol_mm else None), info


def identify_from_camera(cam, cfg):
    from common.config import recipes_available
    img = cam.grab()
    return classify(measure(img, cfg), recipes_available(cfg))


if __name__ == "__main__":
    from common.config import load_config, recipes_available
    ap = argparse.ArgumentParser()
    ap.add_argument("--image")
    a = ap.parse_args()
    cfg = load_config()
    if a.image:
        img = cv2.imread(a.image)
    else:
        from vision.camera import Camera
        cam = Camera(cfg); img = cam.grab(); cam.release()
    print(classify(measure(img, cfg), recipes_available(cfg)))
