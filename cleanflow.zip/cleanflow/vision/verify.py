"""Placement check: is there a screw head in the target hole? (presence check, not quality inspection)

Compares a circular ROI around the hole with a reference image taken while the holes were empty.
Robust to slight lighting drift because both images go through the same top-down warp.
"""
from __future__ import annotations

import cv2
import numpy as np

from vision.board import BoardView


class PlacementVerifier:
    def __init__(self, cam, cfg, roi_radius_mm: float = 6.0):
        self.cam, self.cfg, self.r = cam, cfg, roi_radius_mm
        self.view = None
        self.ref = None

    def _topdown(self, img):
        from common.config import board_bounds
        x0, x1, y0, y1 = board_bounds(self.cfg)
        g, s = self.view.warp(img, x0, x1, y0, y1)
        return cv2.cvtColor(g, cv2.COLOR_BGR2GRAY) if g.ndim == 3 else g, s, (x0, y1)

    def capture_reference(self, img=None):
        img = img if img is not None else self.cam.grab()
        self.view = BoardView(self.cfg, img)
        self.ref = self._topdown(img)

    def occupied_score(self, slot, img=None) -> float:
        img = img if img is not None else self.cam.grab()
        cur, s, (x0, y1) = self._topdown(img)
        ref = self.ref[0]
        u, v = int(round((slot.x - x0) * s)), int(round((y1 - slot.y) * s))
        mask = np.zeros_like(cur)
        cv2.circle(mask, (u, v), int(self.r * s), 255, -1)
        return float(cv2.absdiff(cur, ref)[mask > 0].mean())

    def __call__(self, slot, img=None) -> bool:
        return self.occupied_score(slot, img) > self.cfg["camera"]["occupied_diff_thresh"]
